'''
Create a Generator that loops over the given list and prints out only
the items that are divisible by 1111.

'''

'''
Write a script that takes a list and turns it into a tuple.

'''
'''
Write a script that takes a tuple and turns it into a list.

'''
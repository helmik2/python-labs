'''
Write a lambda function that takes in 3 numbers and returns the sum of the numbers.

'''
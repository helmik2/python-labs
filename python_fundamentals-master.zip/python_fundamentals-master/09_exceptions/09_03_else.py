'''
Write a script that demonstrates a try/except/else.

'''
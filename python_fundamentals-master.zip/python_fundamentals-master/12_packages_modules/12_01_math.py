'''
Demonstrate how to access and print the value of pi to the console.

'''
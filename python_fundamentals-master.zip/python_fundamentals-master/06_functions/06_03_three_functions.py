'''
Write a program with 3 functions. Each function must call
at least one other function and use the return value to do something.

'''

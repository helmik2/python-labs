'''
Print out every prime number between 1 and 100.

'''
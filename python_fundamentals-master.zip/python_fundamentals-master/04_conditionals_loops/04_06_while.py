'''
Use a "while" loop to print out every fifth number counting from 1 to 1000.

'''
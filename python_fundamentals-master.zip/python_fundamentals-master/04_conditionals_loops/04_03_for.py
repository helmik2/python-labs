'''
Using a "for-loop", print out all odd numbers from 1-100.

'''
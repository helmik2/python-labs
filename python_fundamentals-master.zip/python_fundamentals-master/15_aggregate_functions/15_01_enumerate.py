'''
Demonstrate the use of the .enumerate() function.
'''
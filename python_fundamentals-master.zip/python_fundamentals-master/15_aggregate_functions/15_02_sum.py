'''
Write a simple aggregate function, sum(), that takes a list a returns the sum.

'''
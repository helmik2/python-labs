"""
Write a decorator function that wraps text passed to it in a html <p> tag.
"""

'''
Write a script with a function that demonstrates the use of **kwargs.

'''
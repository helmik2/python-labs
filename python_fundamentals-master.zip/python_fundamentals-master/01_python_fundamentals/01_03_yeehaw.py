'''
Write the necessary code to display the follow message to the console

	I'm a programmer now.
	Yeehaw!
	Coding here I come!

'''
'''
Write the necessary code to print the result of the following formula:

	(15.7 * 3.6 - 34.9 * 0.9) / (68.9 - 2.1)

'''
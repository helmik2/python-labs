'''
Write the necessary code to print out the result of the following:

	2 + 4 + 6 + 8 + 9 + 10 + 12 + 14 + 16 + 18

'''